../PASS -f AAreadsLEN6-COV30.fa -m 4 -w 1 -o 1 -r 0.51
