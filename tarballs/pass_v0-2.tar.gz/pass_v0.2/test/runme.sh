../PASS -f AAreadsLEN6-COV30.fa -m 4 -w 1 -o 1 -b len6
../PASS -f AAreadsLEN8-COV30.fa -m 4 -w 1 -o 1 -b len8
../PASS -f AAreadsLEN10-COV30.fa -m 4 -w 1 -o 1 -b len10
../PASS -f AAreadsLEN12-COV30.fa -m 4 -w 1 -o 1 -b len12
